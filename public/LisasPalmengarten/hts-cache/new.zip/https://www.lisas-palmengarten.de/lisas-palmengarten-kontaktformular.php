<!DOCTYPE html>
<html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
<meta content="IE=edge" http-equiv="X-UA-Compatible">
<title>lisas-palmengarten-kontaktformular</title>
<style>
body {margin:0; padding:1em; background-color:white;}
#she {background-color:white;color:#0080ff;font-family:Oswald, Arial,Helvetica,sans-serif;font-size:1em;font-weight:normal;max-width:800px;}
</style>
</head>
<body>
<div id="she">
<div id="awf-form"><script>
var awf_file='lisas-palmengarten-kontaktformular.php';
var awf_x=new XMLHttpRequest();awf_x.open('GET',awf_file+'?js=awf');awf_x.onreadystatechange=function(){if(awf_x.readyState===4&&awf_x.status===200){var s=document.createElement('script');s.innerHTML=awf_x.responseText;document.head.appendChild(s);awf_Run('awf-form');}};awf_x.send();
</script></div>
<noscript>Bitte aktivieren Sie Javascript in Ihrem Browser!</noscript>
</div>
</body>
</html>
